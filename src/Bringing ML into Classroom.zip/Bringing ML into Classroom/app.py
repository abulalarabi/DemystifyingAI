# Define the Dash App and it's properties here

import dash
import dash_bootstrap_components as dbc
from dash_extensions.enrich import Output, DashProxy, Input, MultiplexerTransform

app = DashProxy(__name__, transforms=[MultiplexerTransform()],external_stylesheets=[dbc.themes.BOOTSTRAP]
                ,meta_tags=[{"name": "viewport", "content": "width=device-width,initial-scale=1.0"}],suppress_callback_exceptions=True)

app.config['suppress_callback_exceptions'] = True

 # app=DashProxy(__name__,external_stylesheets=[dbc.themes.BOOTSTRAP],meta_tags=[{"name": "viewport", "content": "width=device-width"}],
 #                 suppress_callback_exceptions=True,prevent_initial_callbacks=True, transforms=[MultiplexerTransform()])

# app = dash.Dash(__name__,
#                 external_stylesheets=[dbc.themes.BOOTSTRAP],
#                 meta_tags=[{"name": "viewport", "content": "width=device-width"}],
#                 suppress_callback_exceptions=True)
